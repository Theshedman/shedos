export declare function startServer(ts: typeof import('typescript')): void;
